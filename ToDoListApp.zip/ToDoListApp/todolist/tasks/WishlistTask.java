package todolist.tasks;
// WishlistTask implements Displayable automatically through Task
public class WishlistTask extends Task {

public WishlistTask(String title, String description, int priority)
{
super(title, description, priority);
}
@Override
public void showTask()
{
// Use interface display method
printInfo();
}
@Override
public void printInfo()
{
// Custom print style for wishlist tasks
String status = isCompleted() ? "purchased / fulfilled." : "still on wishlist.";
System.out.println("[Wishlist] " + getTitle() + " " + status +" | Priority: " + getPriority());
}
}