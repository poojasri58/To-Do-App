package todolist.tasks;

public class BirthdayTask extends Task {
public BirthdayTask(String title, String desc, int priority)
{
super(title, desc, priority);
}
public void showTask()
{
if (completed)
System.out.println("[Birthday] " + title + " is done.");
else
System.out.println("[Birthday] " + title + " needs to be done.");
}
}