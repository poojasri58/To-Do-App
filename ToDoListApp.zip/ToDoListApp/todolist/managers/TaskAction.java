package todolist.managers;

@FunctionalInterface
public interface TaskAction<T>
{
    void execute(T task);
}
