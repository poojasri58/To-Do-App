package users;
import java.io.IOException;
public class Auth
{
private UserManager userManager = new UserManager();
// Register a new user
public void register(String username, String password) throws AuthException
{
userManager.registerUser(username, password);
}
// Login
public boolean login(String username, String password)
{
try {
return userManager.login(username, password) != null;
}
catch (UserNotFoundException e)
{
System.out.println("Error: " + e.getMessage());
return false;
// Handles case when user not found
}
catch (AuthException e)
{
System.out.println("Error: " + e.getMessage());

return false;
// Handles authentication-related errors
}
}
// Show all registered users
public void showUsers()
{
userManager.showUsers();
}
// Check if user already exists
public boolean isUserExists(String username)
{
return userManager.isUserExists(username);
}
}