package users;
public class AuthException extends Exception {
public AuthException(String msg)
{
super(msg);
}
}