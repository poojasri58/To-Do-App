package users;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class UserManager
{
private final String FILE_PATH = "users.txt"; // file to store users
private List<User> users;
public UserManager()
{
users = new ArrayList<>();
loadUsersFromFile();
}
// Register a new user
public void registerUser(String username, String password) throws AuthException {
if (isUserExists(username)) {
throw new AuthException("Username already exists!"); // Custom Exception
}
User u = new User(username, password);
users.add(u); //Collection - Adding elements to ArrayList
saveUsersToFile();
System.out.println("User registered successfully!");
}

// Login
public User login(String username, String password) throws AuthException, UserNotFoundException {
for (User u : users) //for each loop
{
if (u.getUsername().equals(username))
{
if (u.checkPassword(password))
return u;
else
throw new AuthException("Incorrect password!");
}
}
throw new UserNotFoundException("User '" + username + "' not found!");
}
// Show all registered users
public void showUsers()
{
if (users.isEmpty())
{
System.out.println("No users registered yet.");
return;
}
System.out.println("\n--- Registered Users ---");
for (int i = 0; i < users.size(); i++)
{
System.out.println((i + 1) + ". " + users.get(i).getUsername());
}
}
// Check if user exists
public boolean isUserExists(String username)
{
for (User u : users)
{
if (u.getUsername().equals(username)) return true;
}
return false;
}
// Load users from file
private void loadUsersFromFile()
{
File file = new File(FILE_PATH);
if (!file.exists()) //pg 643
return;
try (BufferedReader br = new BufferedReader(new FileReader(file)))

{
String line;
while ((line = br.readLine()) != null) {
String[] parts = line.split(","); // string tokenizer
if (parts.length == 2)
{
users.add(new User(parts[0], parts[1]));
}
}
}
catch (IOException e)
{
System.out.println("Error reading users file: " + e.getMessage());
}
}
// Save users to file
private void saveUsersToFile()
{
try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH)))
{
for (User u : users)
{
bw.write(u.getUsername() + "," + u.getPassword());
bw.newLine();
}
}
catch (IOException e)
{
System.out.println("Error writing users file: " + e.getMessage());
}
}
}