package todolist.managers;

import java.util.*;
import java.util.StringTokenizer;
import todolist.tasks.PersonalTask;
import todolist.tasks.Task;

public class PersonalManager
{
    private final List<Task> tasks = new ArrayList<>();

    public void showMenu()
    {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n--- Personal Tasks ---");
            System.out.println("1. Add Task");
            System.out.println("2. Add Multiple Tasks (comma separated)");
            System.out.println("3. Display Tasks");
            System.out.println("4. Mark Task Completed");
            System.out.println("5. Sort Tasks by Priority");
            System.out.println("6. Update Task Description");
            System.out.println("0. Back");
            System.out.print("Choose: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    addSingleTask(sc);
                    break;
                case 2:
                    addMultipleTasks(sc);
                    break;
                case 3:
                    displayAllTasks();
                    break;
                case 4:
                    markTaskCompleted(sc);
                    break;
                case 5:
                    sortTasksByPriority();
                    break;
                case 6:
                    updateTaskDescription(sc);
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 0);
    }

    private void addSingleTask(Scanner sc)
    {
        System.out.print("Title: ");
        String title = sc.nextLine();
        System.out.print("Description: ");
        String desc = sc.nextLine();
        System.out.print("Priority (1-5): ");
        int priority = sc.nextInt();
        sc.nextLine();
        tasks.add(new PersonalTask(title, desc, priority));
        System.out.println("Task added!");
    }

    private void addMultipleTasks(Scanner sc)
    {
        System.out.print("Enter multiple task titles separated by commas: ");
        String input = sc.nextLine();
        StringTokenizer st = new StringTokenizer(input, ",");

        while (st.hasMoreTokens())
        {
            String title = st.nextToken().trim();
            System.out.print("Enter description for \"" + title + "\": ");
            String desc = sc.nextLine();
            System.out.print("Enter priority (1-5) for \"" + title + "\": ");
            int priority = sc.nextInt();
            sc.nextLine();
            tasks.add(new PersonalTask(title, desc, priority));
            System.out.println("Added task: " + title);
        }
        System.out.println("All tasks added!");
    }

    private void displayAllTasks()
    {
        if (tasks.isEmpty())
        {
            System.out.println("No tasks added yet.");
            return;
        }
        System.out.println("\n--- Personal Tasks ---");
        for (int i = 0; i < tasks.size(); i++)
        {
            System.out.print((i + 1) + ". ");
            tasks.get(i).showTask();
        }
    }

    private void markTaskCompleted(Scanner sc)
    {
        displayAllTasks();
        System.out.print("Enter task number to mark completed: ");
        int idx = sc.nextInt() - 1;
        sc.nextLine();

        if (idx >= 0 && idx < tasks.size())
        {
            TaskAction<Task> markCompletedAction = Task::markCompleted;
            markCompletedAction.execute(tasks.get(idx));
        }
        else
        {
            System.out.println("Invalid task number!");
        }
    }

    private void sortTasksByPriority()
    {
        tasks.sort(Comparator.comparingInt(Task::getPriority));
        System.out.println("Tasks sorted by priority!");
    }

    private void updateTaskDescription(Scanner sc)
    {
        displayAllTasks();
        System.out.print("Enter task number to update description: ");
        int idx = sc.nextInt() - 1;
        sc.nextLine();

        if (idx >= 0 && idx < tasks.size())
        {
            System.out.print("Enter text to append: ");
            String extra = sc.nextLine();
            TaskAction<Task> appendDesc =
                    t -> t.setDescription(t.getDescription() + " " + extra);
            appendDesc.execute(tasks.get(idx));
            System.out.println("Updated description: " + tasks.get(idx).getDescription());
        }
        else
        {
            System.out.println("Invalid task number!");
        }
    }
}
