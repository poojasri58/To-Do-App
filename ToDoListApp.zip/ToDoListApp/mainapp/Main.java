package mainapp;
import java.util.Scanner;
import users.Auth;
import todolist.managers.*;
public class Main
{
public static void main(String[] args)
{
System.out.println("-------------------------------------------------------------------");
System.out.println(" SIMPLE TO-DO LIST APPLICATION ");
System.out.println("-------------------------------------------------------------------");
System.out.println();
System.out.println(" Description: ");
System.out.println(" This project is a console-based To-Do List application that allows");
System.out.println(" users to register, log in, and manage different types of tasks ");
System.out.println(" such as Work, Personal, Birthday, and Wishlist tasks. ");
System.out.println("-------------------------------------------------------------------");
System.out.println();

Scanner sc = new Scanner(System.in);
Auth auth = new Auth();
System.out.println("=== Welcome to Simple Todo List ===");
boolean loggedIn = false;
while (!loggedIn)
{
System.out.println("\n1. Register");
System.out.println("2. Login");
System.out.println("0. Exit");
System.out.print("Enter your choice: ");
int choice = sc.nextInt();
sc.nextLine();
try{
if (choice == 1)

{

System.out.print("Enter username: ");
String username = sc.nextLine();
// Check if username already exists
if (auth.isUserExists(username))

{

System.out.println("Error: Username already exists!");
continue; // skip password prompt
}
System.out.print("Enter password: ");
String password = sc.nextLine();
auth.register(username, password);
}

else if (choice == 2)
{

System.out.print("Enter username: ");
String username = sc.nextLine();
System.out.print("Enter password: ");
String password = sc.nextLine();
if (auth.login(username, password))

{

System.out.println("Login successful! Welcome " + username);
loggedIn = true;
}
else
{

System.out.println("Wrong username or password!");
}
}

else if (choice == 0)
{
System.out.println("Exiting...");

return;
}
else
{

System.out.println("Invalid choice, try again.");
}
}
catch (Exception e)
{
System.out.println("Error: " + e.getMessage());
}
}
// Task Managers
WorkManager workManager = new WorkManager();
PersonalManager personalManager = new PersonalManager();
BirthdayManager birthdayManager = new BirthdayManager();
WishlistManager wishlistManager = new WishlistManager();
while (true)
{
System.out.println("\n--- Main Menu ---");
System.out.println("1. Work Tasks");
System.out.println("2. Personal Tasks");
System.out.println("3. Birthday Tasks");
System.out.println("4. Wishlist Tasks");
System.out.println("5. Show all users");
System.out.println("0. Logout");
System.out.print("Choose an option: ");
int mainChoice = sc.nextInt();
sc.nextLine();
try {
switch (mainChoice)
{
case 1:
workManager.showMenu();
break;
case 2:
personalManager.showMenu();
break;
case 3:
birthdayManager.showMenu();
break;

case 4:
wishlistManager.showMenu();
break;

case 5:

auth.showUsers();
break;
case 0:
System.out.println("Logging out. Bye!");
return;
default:
System.out.println("Invalid choice.");
}
}
catch (Exception e) //Exception Handling
{
System.out.println("Error: " + e.getMessage());
}
}
}
}