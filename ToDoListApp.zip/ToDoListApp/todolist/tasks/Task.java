package todolist.tasks;

public abstract class Task implements Displayable
{
    protected String title;
    protected String description;
    protected int priority;
    protected boolean completed;

    public Task(String title, String description, int priority)
    {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.completed = false;
    }

    public void markCompleted()
    {
        try {
            System.out.println("Marking task '" + title + "' as completed...");
            Thread.sleep(2000);
            completed = true;
            System.out.println("Task '" + title + "' completed!");
        }
        catch (InterruptedException e)
        {
            System.out.println("Task completion interrupted!");
        }
    }

    public boolean isCompleted()
    {
        return completed;
    }

    public String getTitle()
    {
        return title;
    }

    public String getDescription()
    {
        return description;
    }

    public int getPriority()
    {
        return priority;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public abstract void showTask();

    @Override
    public void printInfo()
    {
        System.out.println(title + " | Priority: " + priority + " | Completed: " + completed);
    }
}
