package todolist.tasks;

// Interface to display task info
public interface Displayable
{
    void printInfo();
}
