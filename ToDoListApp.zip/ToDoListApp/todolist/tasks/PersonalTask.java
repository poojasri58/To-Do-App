package todolist.tasks;
public class PersonalTask extends Task {
public PersonalTask(String title, String desc, int priority)
{
super(title, desc, priority);

}
public void showTask()
{
if (completed)
System.out.println("[Personal] " + title + " is done.");
else
System.out.println("[Personal] " + title + " needs to be done.");
}
}