package todolist.tasks;
public class WorkTask extends Task
{
public WorkTask(String title, String description, int priority)
{
super(title, description, priority);
}
@Override
public void showTask()
{
// Call the interface method instead of old print
printInfo();
}
@Override
public void printInfo()
{
// Customize interface display for Work tasks
String status = isCompleted() ? "done." : "needs to be done.";
System.out.println("[Work] " + getTitle() + " " + status +
" | Priority: " + getPriority());

}
}